# AniFlare — Futuristic Anime Streaming Index

A lightweight, static frontend + Firebase Realtime Database admin system.

## Included

- Futuristic responsive homepage
- Trending / latest / ongoing / genre pages
- Anime detail pages
- Season + episode library
- External Watch Online URL
- 480p / 720p / 1080p external download URLs
- Firebase Realtime Database CRUD
- Admin console at `/admin.html`
- No video hosting required

## Firebase

Configured database:
`https://anistreamx-903a3-default-rtdb.firebaseio.com/`

The frontend uses Firebase's browser SDK from Google's CDN.

### Important: Firebase security

This starter assumes you will add Firebase Authentication and restrictive Realtime Database Rules before exposing the admin console publicly. Do not treat the admin page as secure merely because it is not linked in the main navigation.

For a production deployment:
1. Enable Firebase Authentication.
2. Create an admin user.
3. Restrict writes to authenticated/admin users in Realtime Database Rules.
4. Keep public reads only for the catalog data you want visitors to see.

## Data shape

```text
aniflare/
  anime/
    <animeId>/
      title
      poster
      backdrop
      year
      rating
      type
      status
      language
      genres
      description
      seasons/
        <seasonId>/
          name
          episodes/
            <episodeId>/
              number
              title
              watchUrl
              links/
                480p
                720p
                1080p
```

## Run locally

Because ES modules are used, serve the folder through a local web server instead of opening `index.html` directly.

Examples:

```bash
python -m http.server 8080
```

Then open:

`http://localhost:8080/`

Admin:

`http://localhost:8080/admin.html`

## Deploy

This is a static site and can be deployed to GitHub Pages, Netlify, Cloudflare Pages, Vercel, or any normal static hosting provider.

## Next upgrade

When your streaming-link bot is ready, replace each episode's `watchUrl` with the generated streaming URL. The frontend already has a dedicated Watch Online action, so the UI does not need to be rebuilt.


## Troubleshooting a blank deployed website

If the visual shell loads but catalog data is empty, open the browser console/network panel and check Firebase access. The updated build now displays a visible Firebase connection notice instead of failing silently.

For Admin, open the exact file:
`/admin.html`

If Firebase Rules currently require authentication, the public catalog will also need public read access (or the frontend must authenticate before reading). The sample rules in `firebase-rules.example.json` are intended as a starting point, not a complete production auth setup.
