import { db, ref, get, set, push, update, remove, onValue } from "./firebase.js";

const ROOT = "aniflare";

export function watchCatalog(callback, onError) {
  try {
    return onValue(
      ref(db, ROOT),
      snap => callback(snap.exists() ? snap.val() : {}),
      err => onError?.(err)
    );
  } catch (e) {
    onError?.(e);
    return () => {};
  }
}

export async function getCatalog() {
  const snap = await get(ref(db, ROOT));
  return snap.exists() ? snap.val() : {};
}

export async function saveAnime(anime, id=null) {
  const animeRef = id ? ref(db, `${ROOT}/anime/${id}`) : push(ref(db, `${ROOT}/anime`));
  const key = id || animeRef.key;
  await set(animeRef, {...anime, id:key, updatedAt:Date.now()});
  return key;
}

export async function deleteAnime(id) {
  await remove(ref(db, `${ROOT}/anime/${id}`));
}

export async function saveEpisode(animeId, seasonId, episode, episodeId=null) {
  const base = `${ROOT}/anime/${animeId}/seasons/${seasonId}/episodes`;
  const epRef = episodeId ? ref(db, `${base}/${episodeId}`) : push(ref(db, base));
  const key = episodeId || epRef.key;
  await set(epRef, {...episode, id:key, updatedAt:Date.now()});
  return key;
}

export async function deleteEpisode(animeId, seasonId, episodeId) {
  await remove(ref(db, `${ROOT}/anime/${animeId}/seasons/${seasonId}/episodes/${episodeId}`));
}
