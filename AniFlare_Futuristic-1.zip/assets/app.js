import { watchCatalog } from "./data.js";

const app = document.querySelector("#app");
let catalog = {};

const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const arr = x => x ? Object.values(x) : [];
const allAnime = () => arr(catalog.anime);
const poster = a => a.poster || "https://placehold.co/600x850/0d1220/ffffff?text=No+Poster";

function layout(content) {
  return `<header class="topbar">
    <a class="brand" href="#/"><span class="brand-mark">✦</span> ANIFLARE</a>
    <nav><a href="#/">Home</a><a href="#/latest">Latest</a><a href="#/ongoing">Ongoing</a><a href="#/genres">Genres</a></nav>
    <div class="top-actions"><a class="admin-link" href="admin.html">Admin</a><button class="icon-btn" id="searchBtn">⌕</button></div>
  </header>
  <main>${content}</main>
  <footer><div><b>ANIFLARE</b><span> Futuristic anime index</span></div><small>External streaming & download links are provided by the site administrator.</small></footer>`;
}

function card(a) {
  return `<a class="anime-card" href="#/anime/${encodeURIComponent(a.id)}">
    <div class="poster-wrap"><img loading="lazy" src="${esc(poster(a))}" alt="${esc(a.title)}"><span class="type">${esc(a.type || "TV")}</span></div>
    <div class="card-info"><h3>${esc(a.title)}</h3><p>${esc(a.year || "—")} • ★ ${esc(a.rating || "N/A")}</p></div>
  </a>`;
}

function home() {
  const anime = allAnime();
  const featured = anime.slice(0,1)[0];
  return layout(`
    <section class="hero ${featured ? "" : "empty-hero"}" ${featured ? `style="--hero:url('${esc(featured.backdrop || featured.poster || "")}')"` : ""}>
      <div class="hero-content"><span class="eyebrow">ANIFLARE // NEXT-GEN ANIME INDEX</span>
      <h1>${esc(featured?.title || "Your Anime Universe")}</h1>
      <p>${esc(featured?.description || "Discover anime, open episode links, and jump directly to external watch or download destinations.")}</p>
      ${featured ? `<a class="primary-btn" href="#/anime/${encodeURIComponent(featured.id)}">Explore Anime <span>→</span></a>` : `<a class="primary-btn" href="#/latest">Explore Catalog <span>→</span></a>`}
      </div><div class="hero-glow"></div>
    </section>
    <section class="section"><div class="section-head"><div><span class="kicker">CURATED</span><h2>Trending Now</h2></div><a href="#/latest">View all →</a></div>
    <div class="grid">${anime.slice(0,12).map(card).join("") || `<div class="empty">No anime has been added yet. Use Admin to create your first entry.</div>`}</div></section>
    <section class="feature-strip"><div><span>01</span><b>FAST DISCOVERY</b><small>Clean, responsive browsing</small></div><div><span>02</span><b>EPISODE HUB</b><small>Watch & download destinations</small></div><div><span>03</span><b>FUTURE READY</b><small>Streaming-bot links can be added later</small></div></section>`);
}

function listPage(title, items) {
  return layout(`<section class="page-head"><span class="kicker">ANIFLARE</span><h1>${esc(title)}</h1><p>${items.length} titles available</p></section><section class="section"><div class="grid">${items.map(card).join("") || `<div class="empty">Nothing here yet.</div>`}</div></section>`);
}

function genres() {
  const genres = [...new Set(allAnime().flatMap(a => (a.genres || "").split(",").map(x=>x.trim()).filter(Boolean)))];
  return layout(`<section class="page-head"><span class="kicker">BROWSE</span><h1>Genres</h1></section><section class="genre-grid">${genres.map(g=>`<a href="#/genre/${encodeURIComponent(g)}">${esc(g)} <span>→</span></a>`).join("") || "<div class='empty'>Add genres from Admin.</div>"}</section>`);
}

function animePage(id) {
  const a = allAnime().find(x => x.id === id);
  if (!a) return layout(`<section class="empty page-empty">Anime not found.</section>`);
  const seasons = arr(a.seasons);
  return layout(`<section class="details" style="--poster:url('${esc(a.backdrop || a.poster || "")}')">
    <div class="detail-poster"><img src="${esc(poster(a))}" alt="${esc(a.title)}"></div>
    <div class="detail-main"><span class="kicker">${esc(a.status || "AVAILABLE")} • ${esc(a.type || "TV")}</span><h1>${esc(a.title)}</h1>
    <div class="meta">★ ${esc(a.rating || "N/A")} &nbsp; • &nbsp; ${esc(a.year || "—")} &nbsp; • &nbsp; ${esc(a.language || "English")}</div>
    <p>${esc(a.description || "No description added.")}</p><div class="tags">${(a.genres || "").split(",").filter(Boolean).map(g=>`<span>${esc(g.trim())}</span>`).join("")}</div></div>
  </section>
  <section class="section"><div class="section-head"><div><span class="kicker">EPISODES</span><h2>Season Library</h2></div></div>
  ${seasons.map((s,i)=>`<div class="season"><h3>${esc(s.name || `Season ${i+1}`)}</h3><div class="episode-list">${arr(s.episodes).map(e=>`<a class="episode" href="#/watch/${encodeURIComponent(a.id)}/${encodeURIComponent(s.id)}/${encodeURIComponent(e.id)}"><span class="ep-no">${esc(e.number || "—")}</span><span><b>${esc(e.title || `Episode ${e.number || ""}`)}</b><small>${esc(e.duration || "")}</small></span><span>→</span></a>`).join("") || "<div class='empty'>No episodes in this season.</div>"}</div></div>`).join("") || "<div class='empty'>No seasons yet.</div>"}</section>`);
}

function watchPage(aid, sid, eid) {
  const a = allAnime().find(x=>x.id===aid);
  const s = arr(a?.seasons).find(x=>x.id===sid);
  const e = arr(s?.episodes).find(x=>x.id===eid);
  if (!a || !s || !e) return layout(`<section class="empty page-empty">Episode not found.</section>`);
  const watch = e.watchUrl || "";
  const links = e.links || {};
  return layout(`<section class="watch-head"><span class="kicker">${esc(a.title)} • ${esc(s.name || "Season")}</span><h1>${esc(e.title || `Episode ${e.number}`)}</h1><p>Choose a destination below.</p></section>
    <section class="watch-panel">
      <div class="player-placeholder"><div class="scanline"></div><span>STREAMING MODULE</span><b>External player mode</b><small>Website video hosting is disabled for this build.</small></div>
      <div class="link-actions">
        ${watch ? `<a class="primary-btn" target="_blank" rel="noopener" href="${esc(watch)}">▶ Watch Online</a>` : ""}
        ${links["480p"] ? `<a class="quality-btn" target="_blank" rel="noopener" href="${esc(links["480p"])}"><b>480P</b><span>Download</span></a>` : ""}
        ${links["720p"] ? `<a class="quality-btn" target="_blank" rel="noopener" href="${esc(links["720p"])}"><b>720P</b><span>Download</span></a>` : ""}
        ${links["1080p"] ? `<a class="quality-btn" target="_blank" rel="noopener" href="${esc(links["1080p"])}"><b>1080P</b><span>Download</span></a>` : ""}
      </div>
    </section>`);
}

function router() {
  const hash = location.hash.slice(1) || "/";
  const parts = hash.split("/").filter(Boolean).map(decodeURIComponent);
  let html = parts[0]==="anime" ? animePage(parts[1]) :
    parts[0]==="watch" ? watchPage(parts[1],parts[2],parts[3]) :
    parts[0]==="latest" ? listPage("Latest Releases", allAnime().sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0))) :
    parts[0]==="ongoing" ? listPage("Ongoing Anime", allAnime().filter(a=>(a.status||"").toLowerCase()==="ongoing")) :
    parts[0]==="genres" ? genres() :
    parts[0]==="genre" ? listPage(parts[1], allAnime().filter(a=>(a.genres||"").toLowerCase().includes(parts[1].toLowerCase()))) :
    home();
  app.innerHTML = html;
}
watchCatalog(
  data => { catalog=data || {}; router(); },
  err => {
    catalog = {};
    router();
    const main = document.querySelector("main");
    if (main) {
      main.insertAdjacentHTML("afterbegin",
        `<div class="firebase-notice"><b>Catalog connection unavailable.</b> The UI is working, but Firebase could not be read. Check your Realtime Database Rules and database URL.<small>${esc(err?.message || "Unknown Firebase error")}</small></div>`
      );
    }
  }
);
window.addEventListener("hashchange", router);
