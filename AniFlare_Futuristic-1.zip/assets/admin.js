import { getCatalog, saveAnime, deleteAnime, saveEpisode, deleteEpisode } from "./data.js";

const root = document.querySelector("#admin-app");
let catalog = {};
let selectedAnime = null;

const TMDB_KEY = "e5217b19ceb4f642777872376eee47a5";
const TMDB_IMAGE = "https://image.tmdb.org/t/p/w780";

const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const arr = x => x ? Object.values(x) : [];

async function aniListSearch(query) {
  const gql = `query ($search:String){ Page(page:1,perPage:12){ media(search:$search,type:ANIME,sort:SEARCH_MATCH){ id title{romaji english native} description(asHtml:false) episodes duration averageScore genres status format season seasonYear startDate{year} bannerImage coverImage{large extraLarge} } } }`;
  const r = await fetch("https://graphql.anilist.co", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify({query:gql,variables:{search:query}})
  });
  if(!r.ok) throw new Error("AniList request failed");
  const j=await r.json();
  return j.data?.Page?.media || [];
}

async function tmdbPoster(title, year) {
  const q = encodeURIComponent(title);
  const url = `https://api.themoviedb.org/3/search/tv?api_key=${TMDB_KEY}&query=${q}${year ? `&first_air_date_year=${year}` : ""}&language=en-US`;
  const r=await fetch(url);
  if(!r.ok) throw new Error("TMDB request failed");
  const j=await r.json();
  const hit=(j.results||[]).find(x=>x.poster_path) || (j.results||[])[0];
  return hit?.poster_path ? TMDB_IMAGE+hit.poster_path : "";
}

function chooseTitle(m){ return m.title?.english || m.title?.romaji || m.title?.native || "Untitled Anime"; }

async function buildAnimeFromAniList(m) {
  const title=chooseTitle(m);
  const year=m.startDate?.year || m.seasonYear || "";
  let poster="";
  try { poster=await tmdbPoster(title,year); } catch(e) {}
  if(!poster && m.coverImage?.extraLarge) poster=m.coverImage.extraLarge;
  return {
    title, poster,
    backdrop:m.bannerImage || poster,
    year:year || "",
    rating:m.averageScore ? (m.averageScore/10).toFixed(1) : "",
    type:m.format || "TV",
    status:m.status==="RELEASING" ? "Ongoing" : m.status==="FINISHED" ? "Finished" : (m.status||""),
    language:"English",
    genres:(m.genres||[]).join(", "),
    description:(m.description||"").replace(/<[^>]*>/g,""),
    anilistId:m.id,
    episodesTotal:m.episodes||"",
    duration:m.duration||"",
    seasons:{},
    updatedAt:Date.now()
  };
}

function shell(content) {
  root.innerHTML=`<header class="topbar"><a class="brand" href="index.html#/"><span class="brand-mark">✦</span> ANIFLARE</a><nav><a href="index.html#/">Website</a></nav><div class="top-actions"><span class="admin-badge">ADMIN CONSOLE</span></div></header><main>${content}</main>`;
}

function render() {
  const anime=arr(catalog.anime);
  shell(`<section class="admin-wrap">
    <div class="admin-head"><div><span class="kicker">CONTROL CENTER</span><h1>Catalog Admin</h1><p>Search AniList, fetch anime details and automatically find the vertical poster from TMDB.</p></div></div>

    <section class="import-box">
      <div class="import-title"><div><span class="kicker">AUTO IMPORT</span><h2>Add Anime Automatically</h2><p>Search by anime name → choose result → TMDB poster → save to Firebase.</p></div></div>
      <div class="search-row"><input id="aniSearch" placeholder="Search anime… e.g. Solo Leveling, One Piece"><button class="primary-btn" id="aniSearchBtn">Search Anime</button></div>
      <div id="aniResults" class="ani-results"></div>
    </section>

    <div class="admin-layout">
      <aside class="admin-list">${anime.map(a=>`<button class="admin-item ${selectedAnime?.id===a.id?'active':''}" data-anime="${esc(a.id)}"><img src="${esc(a.poster||"https://placehold.co/80x110/0d1220/fff?text=A")}"><span><b>${esc(a.title)}</b><small>${esc(a.status||"")}</small></span></button>`).join("") || `<div class="empty">No anime yet.</div>`}</aside>
      <section class="admin-editor">${selectedAnime ? editor(selectedAnime) : `<div class="empty editor-empty">Search above to import an anime automatically.</div>`}</section>
    </div>
  </section>`);
  bindSearch();
  document.querySelectorAll("[data-anime]").forEach(b=>b.onclick=()=>{selectedAnime=anime.find(a=>a.id===b.dataset.anime);render();});
  bindEditor();
}

function bindSearch(){
  const input=document.querySelector("#aniSearch"), btn=document.querySelector("#aniSearchBtn"), out=document.querySelector("#aniResults");
  const search=async()=>{
    const q=input.value.trim(); if(!q)return;
    btn.disabled=true; btn.textContent="Searching…"; out.innerHTML=`<div class="loading">Searching AniList…</div>`;
    try{
      const results=await aniListSearch(q);
      out.innerHTML=results.map(m=>`<div class="ani-result">
        <img src="${esc(m.coverImage?.large||"https://placehold.co/100x145/0d1220/fff?text=A")}">
        <div class="ani-result-info"><b>${esc(chooseTitle(m))}</b><small>${esc(m.title?.english && m.title?.english!==chooseTitle(m)?m.title.english:"")} ${m.startDate?.year?"• "+m.startDate.year:""} • ${esc(m.format||"")} • ${esc(m.status||"")}</small><p>${esc((m.description||"").replace(/<[^>]*>/g,"").slice(0,180))}</p></div>
        <button class="secondary-btn import-one" data-id="${m.id}">＋ Add</button>
      </div>`).join("") || `<div class="empty">No anime found.</div>`;
      out.querySelectorAll(".import-one").forEach(b=>b.onclick=async()=>{
        const m=results.find(x=>String(x.id)===b.dataset.id); b.disabled=true;b.textContent="Fetching…";
        try{
          const anime=await buildAnimeFromAniList(m);
          const id=await saveAnime(anime,null);
          catalog=await getCatalog(); selectedAnime=arr(catalog.anime).find(x=>x.id===id);
          b.textContent="Added ✓"; render();
        }catch(e){alert("Import failed: "+e.message);b.disabled=false;b.textContent="＋ Add";}
      });
    }catch(e){out.innerHTML=`<div class="empty">Search failed: ${esc(e.message)}</div>`}
    btn.disabled=false;btn.textContent="Search Anime";
  };
  btn?.addEventListener("click",search);
  input?.addEventListener("keydown",e=>{if(e.key==="Enter")search()});
}

function editor(a) {
  return `<form id="animeForm" class="form-grid"><div class="form-title"><h2>${a.id?"Edit Anime":"New Anime"}</h2><button type="button" class="danger" id="deleteAnime">Delete</button></div>
    <div class="poster-preview full"><img src="${esc(a.poster||"https://placehold.co/220x320/0d1220/fff?text=Poster")}" alt=""><div><span class="kicker">TMDB POSTER</span><p>${a.anilistId?"Automatically imported from AniList + TMDB.":"Manual poster."}</p></div></div>
    ${field("Title","title",a.title)}${field("Poster URL","poster",a.poster)}${field("Backdrop URL","backdrop",a.backdrop)}${field("Year","year",a.year)}${field("Rating","rating",a.rating)}${field("Type","type",a.type)}${field("Status","status",a.status)}${field("Language","language",a.language)}${field("Genres (comma separated)","genres",a.genres)}
    <label class="full">Description<textarea name="description">${esc(a.description)}</textarea></label><div class="full form-actions"><button class="primary-btn">Save Anime</button></div>
  </form>
  <div class="sub-editor"><div class="section-head"><div><span class="kicker">STRUCTURE</span><h2>Seasons & Episodes</h2></div><button type="button" class="secondary-btn" id="newSeason">＋ Season</button></div>
  ${arr(a.seasons).map(s=>seasonEditor(a,s)).join("") || "<div class='empty'>No seasons. Add one to start adding episodes.</div>"}</div>`;
}
function field(label,name,value){return `<label>${esc(label)}<input name="${name}" value="${esc(value)}"></label>`;}
function seasonEditor(a,s){return `<div class="season-admin"><div class="season-admin-head"><b>${esc(s.name)}</b><button type="button" class="secondary-btn addEp" data-s="${esc(s.id)}">＋ Episode</button></div>${arr(s.episodes).map(e=>`<div class="ep-admin"><span>#${esc(e.number)}</span><b>${esc(e.title||"Episode")}</b><div class="ep-links"><a href="${esc(e.watchUrl||"#")}" target="_blank">Watch</a><span>${Object.keys(e.links||{}).join(" / ")}</span></div><button type="button" class="danger deleteEp" data-s="${esc(s.id)}" data-e="${esc(e.id)}">×</button></div>`).join("")||"<div class='empty'>No episodes.</div></div>`}

function bindEditor(){
  const form=document.querySelector("#animeForm");
  if(form)form.onsubmit=async ev=>{ev.preventDefault();const data=Object.fromEntries(new FormData(form));data.seasons=selectedAnime.seasons||{};const id=await saveAnime(data,selectedAnime.id);catalog=await getCatalog();selectedAnime=arr(catalog.anime).find(x=>x.id===id);alert("Anime saved.");render()};
  document.querySelector("#deleteAnime")?.addEventListener("click",async()=>{if(selectedAnime.id&&confirm("Delete this anime?")){await deleteAnime(selectedAnime.id);catalog=await getCatalog();selectedAnime=null;render()}});
  document.querySelector("#newSeason")?.addEventListener("click",async()=>{const name=prompt("Season name","Season 1");if(!name)return;selectedAnime.seasons=selectedAnime.seasons||{};const id="s_"+Date.now();selectedAnime.seasons[id]={id,name,episodes:{}};await saveAnime(selectedAnime,selectedAnime.id);catalog=await getCatalog();selectedAnime=arr(catalog.anime).find(x=>x.id===selectedAnime.id);render()});
  document.querySelectorAll(".addEp").forEach(b=>b.onclick=()=>addEpisode(b.dataset.s));
  document.querySelectorAll(".deleteEp").forEach(b=>b.onclick=async()=>{if(confirm("Delete episode?")){await deleteEpisode(selectedAnime.id,b.dataset.s,b.dataset.e);catalog=await getCatalog();selectedAnime=arr(catalog.anime).find(x=>x.id===selectedAnime.id);render()}});
}
async function addEpisode(sid){const number=prompt("Episode number","1");if(!number)return;const title=prompt("Episode title",`Episode ${number}`)||`Episode ${number}`;const watchUrl=prompt("Watch Online URL (optional)","")||"";const l480=prompt("480p download URL (optional)","")||"";const l720=prompt("720p download URL (optional)","")||"";const l1080=prompt("1080p download URL (optional)","")||"";const links={};if(l480)links["480p"]=l480;if(l720)links["720p"]=l720;if(l1080)links["1080p"]=l1080;await saveEpisode(selectedAnime.id,sid,{number,title,watchUrl,links},null);catalog=await getCatalog();selectedAnime=arr(catalog.anime).find(x=>x.id===selectedAnime.id);render()}

root.innerHTML = `<div class="admin-loading"><div class="brand"><span class="brand-mark">✦</span> ANIFLARE</div><p>Connecting to catalog…</p></div>`;
getCatalog()
  .then(x => { catalog=x || {}; render(); })
  .catch(e => {
    catalog = {};
    root.innerHTML = `<header class="topbar"><a class="brand" href="index.html#/"><span class="brand-mark">✦</span> ANIFLARE</a><nav><a href="index.html#/">Website</a></nav></header>
      <main><section class="page-empty empty admin-error"><h1>Admin connection error</h1><p>The Admin page loaded, but Firebase rejected the database request.</p><code>${esc(e.message || "Unknown Firebase error")}</code><p>Check your Realtime Database Rules and make sure the database URL is correct.</p><a class="primary-btn" href="admin.html">Retry</a></section></main>`;
  });
